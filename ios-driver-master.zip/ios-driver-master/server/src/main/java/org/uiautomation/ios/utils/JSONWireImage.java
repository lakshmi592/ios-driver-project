package org.uiautomation.ios.utils;

/**
 * format of images that are send over the network using the JSONWire protocol.
 */
public interface JSONWireImage {

  public String getAsBase64String();
}
