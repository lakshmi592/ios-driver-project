package org.uiautomation.ios.utils;

import org.uiautomation.ios.IOSCapabilities;

public class ConfigurationValidator {

  public static void validate(IOSCapabilities capabilities) {

  }
}
