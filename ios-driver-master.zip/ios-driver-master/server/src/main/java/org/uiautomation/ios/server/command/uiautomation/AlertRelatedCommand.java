package org.uiautomation.ios.server.command.uiautomation;

/**
 * Created with IntelliJ IDEA. User: freynaud Date: 13/01/2013 Time: 19:49 To change this template
 * use File | Settings | File Templates.
 */
public interface AlertRelatedCommand {

}
