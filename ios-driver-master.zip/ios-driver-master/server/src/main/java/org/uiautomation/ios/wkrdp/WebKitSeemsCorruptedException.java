package org.uiautomation.ios.wkrdp;

import org.openqa.selenium.WebDriverException;
import org.uiautomation.ios.utils.hack.HorribleHack;

public class WebKitSeemsCorruptedException extends WebDriverException implements HorribleHack {

  @Override
  public void activate() {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  @Override
  public void desactivate() {
    //To change body of implemented methods use File | Settings | File Templates.
  }
}
