package org.uiautomation.ios.UIAModels;

public enum ScrollDirection {

  UP,
  DOWN,
  LEFT,
  RIGHT
}
