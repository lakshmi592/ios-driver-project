package org.uiautomation.ios.UIAModels.configuration;

public enum WorkingMode {
  Native, Web;
}
