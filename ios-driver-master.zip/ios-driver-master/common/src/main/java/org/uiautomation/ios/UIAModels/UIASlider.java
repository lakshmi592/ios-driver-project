package org.uiautomation.ios.UIAModels;


public interface UIASlider extends UIAElement {

    public void dragToValue(double value);
}
